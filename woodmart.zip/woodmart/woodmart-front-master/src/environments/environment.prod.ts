export const environment = {
  production: true,
  SERVER_URL: 'http://localhost:3636/api',
};
