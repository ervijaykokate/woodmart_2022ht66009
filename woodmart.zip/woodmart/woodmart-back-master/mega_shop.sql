-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 01, 2023 at 08:41 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mega_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `id` int(11) NOT NULL,
  `line1` varchar(255) DEFAULT NULL,
  `line2` varchar(255) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `pincode` int(6) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`) VALUES
(1, 'Furniture'),
(2, 'Furniture');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`) VALUES
(1, 11),
(155, 11),
(156, 11),
(157, 11),
(158, 11),
(159, 11);

-- --------------------------------------------------------

--
-- Table structure for table `orders_details`
--

CREATE TABLE `orders_details` (
  `id` int(10) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(10) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `orders_details`
--

INSERT INTO `orders_details` (`id`, `order_id`, `product_id`, `quantity`) VALUES
(1, 1, 11, 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `images` text DEFAULT NULL,
  `description` text NOT NULL,
  `price` float NOT NULL,
  `quantity` int(10) NOT NULL,
  `short_desc` varchar(255) NOT NULL,
  `cat_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `image`, `images`, `description`, `price`, `quantity`, `short_desc`, `cat_id`) VALUES
(1, 'Marriott 3 Seater Wooden Sofa', 'https://images.woodenstreet.de/image/cache/data%2Fwooden-sofa%2Fmarriott-wooden-sofa%2Frevised%2Frevised-looks%2Fhoney%2Fupdated-new%2Fsfsdfsdfds-810x702.jpg', 'https://images.woodenstreet.de/image/cache/data%2Fwooden-sofa%2Fmarriott-wooden-sofa%2Frevised%2Frevised-looks%2Fhoney%2Fupdated-new%2F9-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2FA-website-fabric-shoot%2Firish-cream%2F1-810x702.jpg;\r\nhttps://i.ebayimg.com/images/g/j~gAAOSwQ6FdG9Eh/s-l640.jpg;https://images.woodenstreet.de/image/cache/data%2Fwooden-sofa%2Fmarriott-wooden-sofa%2FDimensions-cm%2F17-810x702.jpg;https://i.ebayimg.com/images/g/j~gAAOSwQ6FdG9Eh/s-l640.jpg', '1. Inspired with the modern decor, Marriott wooden 3 seater sofa has all the qualities of the same. This sofa has indented box at the sides that add to the aesthetics of the furniture.\r\n2. This sofa is made in sheesham wood and is further coated in wooden grain shade.\r\n​3. It is available in three finish options of honey, teak and walnut finish.', 36000, 0, 'Gaming console', 2),
(2, '4 Door Wardrobe With Shelf', 'https://images.woodenstreet.de/image/cache/data%2Fwardrobes-mdf%2Fkriva-4-door-wardrobe-with-shelf-grey-finish%2F2-810x702.jpg', 'https://images.woodenstreet.de/image/cache/data%2Fwardrobes-mdf%2Fkriva-4-door-wardrobe-with-shelf-grey-finish%2F4-810x702.jpg;https://i.ebayimg.com/images/g/j~gAAOSwQ6FdG9Eh/s-l640.jpg;https://images.woodenstreet.de/image/cache/data%2Fwardrobes-mdf%2Fkriva-4-door-wardrobe-with-shelf-grey-finish%2F4-810x702.jpg;\r\nhttps://images.woodenstreet.de/image/cache/data%2Fwardrobes-mdf%2Fkriva-4-door-wardrobe-with-shelf-grey-finish%2F4-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fwardrobes-mdf%2Fkriva-4-door-wardrobe-with-shelf-grey-finish%2F3-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fwardrobes-mdf%2Fkriva-4-door-wardrobe-with-shelf-grey-finish%2F2-810x702.jpg', 'About Material & Finish:The Kriva 4-Door Wardrobe with Shelf is meticulously crafted from high-quality wood to ensure durability and longevity. It boasts a sleek and modern finish that adds a touch of sophistication to your bedroom decor. Manufacturing Details & Stringent Quality Checks:This wardrobe undergoes rigorous quality checks during manufacturing to meet the highest standards. The wood used is carefully selected for its strength and quality, and the finish is expertly applied to create a smooth and elegant surface. Product Features:This wardrobe features four doors, offering ample space to accommodate a wide range of clothing, accessories, and personal items. The spacious design helps you keep your bedroom organized and clutter-free. A built-in shelf adds functionality, allowing you to store shoes, bags, folded clothes, or other items separately for better organization. Its minimalist look and clean lines can seamlessly fit into various interior styles. Crafted with precision and attention to detail, this wardrobe is built to withstand daily use. The high-quality wood and expert finish ensure both durability and visual appeal.', 59000, 51, 'SPORTS SHOES', 1),
(3, 'Wood Bed With Storage Drawers', 'https://images.woodenstreet.de/image/cache/data%2Fbed-with-storage%2Fferguson-bed-with-storage%2Fhoney%2Fupdated%2F1-810x702.jpg', 'https://images.woodenstreet.de/image/cache/data%2Fbed-with-storage%2Fferguson-bed-with-storage%2Fhoney%2Fupdated%2F2-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fbed-with-storage%2Fferguson-bed-with-storage%2Fhoney%2Fupdated%2F3-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fbed-with-storage%2Fferguson-bed-with-storage%2Fhoney%2Fupdated%2F4-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fbed-with-storage%2Fferguson-bed-with-storage%2Fhoney%2Fupdated%2F4-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fbed-with-storage%2Fferguson-bed-with-storage%2Fhoney%2Fupdated%2F5-810x702.jpg', 'Storage space has become an asset in urban India. Ferguson Bed with storage comes in king size. Owing to its large size, these beds are really comfortable as you can effortlessly stretch your body and sleep on them. Also due to their large size, they offer ample amount of storage space underneath them. You can store your extra mattresses, duvets, bed sheets, pillows, blankets or anything else you like in this king size bed with storage space. They also have small compartments on the back rest where you can keep your books and other stuff. That makes these double beds highly convenient. Made from very high standard wood, their honey finish adds a special exuberance to your home. These beds are a perfect combination of style, comfort and convenience.', 80000, 69, 'SPORTS SHOES', 1),
(4, '2 Seater Printed Dining Set', 'https://images.woodenstreet.de/image/cache/data%2Fdining-set%2F2-seater%2Fbonita-2-seater-dining-mango-wood%2Fupdated%2F1-810x702.jpg', 'https://images.woodenstreet.de/image/cache/data%2FA-website-fabric-shoot%2Fdusky-leaf%2F1-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fdining-set%2F2-seater%2Fbonita-2-seater-dining-mango-wood%2Fupdated%2F2-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fdining-set%2F2-seater%2Fbonita-2-seater-dining-mango-wood%2Fupdated%2F3-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fdining-set%2F2-seater%2Fbonita-2-seater-dining-mango-wood%2Fupdated%2FTF-1-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fdining-set%2F2-seater%2Fbonita-2-seater-dining-mango-wood%2Fupdated%2F7-810x702.jpg', '1. Adopted from the English culture, Bonita 2 seater dining set is one such sophisticated design of furniture unit. The legs of the table are carved and detailed nicely that contrast the flat square tabletop. With this, the set of upholstered chairs with detailed wooden legs adds to the grace. The prints over the upholstered chairs contrast well with the theme.\r\n2. This dining set is made in mango wood.\r\n​3. The wooden furniture is available in teak finish and is enhanced with upholstery in dusky leaf pattern.', 35000, 78, 'Gaming console', 2),
(5, 'Adolph Bedside Table', 'https://images.woodenstreet.de/image/cache/data%2Fbedside-tables%2Fadolph-bedside-table%2Frevised%2Fhoney%2Fupdated%2F1-810x702.jpg', 'https://images.woodenstreet.de/image/cache/data%2Fbedside-tables%2Fadolph-bedside-table%2Frevised%2Fhoney%2Fupdated%2F1-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fbedside-tables%2Fadolph-bedside-table%2Frevised%2Fhoney%2Fupdated%2F2-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fbedside-tables%2Fadolph-bedside-table%2Frevised%2Fhoney%2Fupdated%2F4-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fbedside-tables%2Fadolph-bedside-table%2Frevised%2Fhoney%2Fupdated%2F5-810x702.jpg', 'Adolph bedside table is one such example of contemporary and conventional furniture design. Its slotted detail is its prominent feature and drawer and door use lengthier slots as handles. Made out of Sheesham, it sticks to high quality.There are several finish options like honey, teak, walnut and mahogany to choose from.', 67000, 83, 'Gaming console', 2),
(6, 'Sculpa Wall Shelf', 'https://images.woodenstreet.de/image/cache/data%2Fwall-shelves%2Fsculpa-wall-shelf%2Fupdated%2Fwalnut-finish%2F1-810x702.jpg', 'https://images.woodenstreet.de/image/cache/data%2Fwall-shelves%2Fsculpa-wall-shelf%2Fupdated%2Fwalnut-finish%2F1-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fwall-shelves%2Fsculpa-wall-shelf%2Fupdated%2Fwalnut-finish%2F2-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fwall-shelves%2Fsculpa-wall-shelf%2Fupdated%2Fwalnut-finish%2Fw-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fwall-shelves%2Fsculpa-wall-shelf%2Fupdated%2Fwalnut-finish%2F4-810x702.jpg', '1. Balance multi-utility and subtle looks in your ensemble with the stunning Sculpa wall shelf. Featuring two spacious rectangular blocks, this shelving unit keeps everything in an organized way. The bit extended corners are sure to bring unique charm to the whole theme.\r\n2. Finely made out of the best quality of Sheesham wood.\r\n​3. Available in a wide range of smooth finish options to cater to your needs.', 9000, 1, 'SPORTS SHOES', 1),
(7, ' Medium Back Office Revolving Chair', 'https://images.woodenstreet.de/image/cache/data%2Fda-urban%2Fmilan-beige-medium-back-office-revolving-chair%2Fupdated%2F1-810x702.jpg', 'https://images.woodenstreet.de/image/cache/data%2Fda-urban%2Fmilan-beige-medium-back-office-revolving-chair%2Fupdated%2F1-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fda-urban%2Fmilan-beige-medium-back-office-revolving-chair%2Fupdated%2F2-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fda-urban%2Fmilan-beige-medium-back-office-revolving-chair%2Fupdated%2F3-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fda-urban%2Fmilan-beige-medium-back-office-revolving-chair%2Fupdated%2Fdimendion1-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fda-urban%2Fmilan-beige-medium-back-office-revolving-chair%2Fupdated%2F5-810x702.jpg', 'Brand Name: Da Urban\r\n\r\nMerchant Name: Metro Furniture\r\n\r\nMerchant Address: Kh. No. 136/2, Near Shivalya Temple, Badli, Village, North West Delhi, 110042\r\n\r\nCountry Of Origin: India\r\n\r\nCountry Of Assembly: India\r\n\r\nManufacturer Country: India\r\n\r\nManufacturer Name: Metro Furniture\r\n\r\nManufacturer Address: Kh. No. 136/2, Near Shivalya Temple, Badli, Village, North West Delhi, 110042\r\n\r\nPacker Name: Metro Furniture\r\n\r\nPacker Address: Kh. No. 136/2, Near Shivalya Temple, Badli, Village, North West Delhi, 110042\r\n\r\nPackage Detail : Milan Beige Medium Back Office Revolving Chair\r\n\r\nWeight In Kg: 1\r\n\r\nGeneric Name : Milan Beige Medium Back Office Revolving Chair\r\n\r\nDimensions (Meter) Metrology : 0.5 L X 0.6 W X 1 H\r\n\r\nDimensions (Cm) Metrology : 48.3 L X 58.4 W X 96.5 H', 8049, 95, 'SPORTS SHOES', 1),
(8, 'Hydraulic Study Table', 'https://images.woodenstreet.de/image/cache/data%2Fstudy-tables-mdf%2Fremo-hydraulic-study-table%2Fice-beech%2Fupdated%2F1-810x702.jpg', 'https://images.woodenstreet.de/image/cache/data%2Fstudy-tables-mdf%2Fremo-hydraulic-study-table%2Fice-beech%2Fupdated%2F1-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fstudy-tables-mdf%2Fremo-hydraulic-study-table%2Fice-beech%2Fupdated%2F2-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fstudy-tables-mdf%2Fremo-hydraulic-study-table%2Fice-beech%2Fupdated%2Fdimension-3-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Fstudy-tables-mdf%2Fremo-hydraulic-study-table%2Fice-beech%2Fupdated%2FIBF-810x702.jpg', '1. Want extraordinary furniture for your study area? Our Remo hydraulic study table can be suitable for you. It enables you to sit at a comfortable position according to your body with the height adjustability feature.\r\n2. Crafted finely from the long-lasting combination of metal and premium engineered wood to ensure durability and comfortable use.\r\n3. The gas-lift technology in this table makes it easy to use and can be adjustable with an easy press of a hand lever.\r\n​4. It is available in different captivating finish options to blend with your home interiors. Caution:​1. The static load capacity is 100 Kgs and the dynamic capacity is 15 Kgs.\r\n2. Do not worry if the desk doesn’t lift up by itself initially. At first, you have to give a little pull force by hands to make it lift up.\r\n​3. If not used wisely, the desk may get tilt, so children need to be accompanied by adult.', 45678, 100, 'Gaming console', 2),
(9, 'Office Table with Three Drawers', 'https://images.woodenstreet.de/image/cache/data%2Foffice-table%2Fnexora-l-shape-modular-office-table-with-three-drawers-flowery-wenge-frosty-white%2Fexotic-teak-finish%2F1-810x702.jpg', 'https://images.woodenstreet.de/image/cache/data%2Foffice-table%2Fnexora-l-shape-modular-office-table-with-three-drawers-flowery-wenge-frosty-white%2Fexotic-teak-finish%2F1-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Foffice-table%2Fnexora-l-shape-modular-office-table-with-three-drawers-flowery-wenge-frosty-white%2Fexotic-teak-finish%2F2-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Foffice-table%2Fnexora-l-shape-modular-office-table-with-three-drawers-flowery-wenge-frosty-white%2Fexotic-teak-finish%2F4-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2FA-website-fabric-shoot%2FFrosty-white-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Foffice-table%2Fnexora-l-shape-modular-office-table-with-three-drawers-flowery-wenge-frosty-white%2Fexotic-teak-finish%2FW-810x702.jpg', 'About Material & Finish: Made of high-quality and premium engineered wood, this Nexora L-Shape Modular Office Table is sturdy in nature and offers lasting durability. The Nexora L-Shape Modular Office Table is available in various finish options that can enhance any space. Manufacturing Details & Stringent Quality Checks: We use fully automated machines in manufacturing our products to achieve extreme accuracy and the utmost level of perfection. The final product passes through stringent quality checks before reaching your doorstep.Product Features:The Nexora L-Shape Modular Office Table is a perfect choice for those who value both functionality and design. The desk is crafted from high-quality engineered wood, and the exotic finish gives it a luxurious and elegant look. The L-shape design offers ample workspace, while the three drawers provide ample storage for files and stationery. Additionally, the desk is modular, which means that you can rearrange the parts to suit your needs. The desk is easy to assemble and is suitable for both home and office use.', 35956, 100, 'Gaming console', 2),
(10, 'Lorenz 3 Seater Sofa', 'https://images.woodenstreet.de/image/cache/data%2Ffabric-sofa%2Fadrick-3-seater-sofa%2Fproduct%2FDark-olive-green%2F2-810x702.jpg', 'https://images.woodenstreet.de/image/cache/data%2Ffabric-sofa%2Fadrick-3-seater-sofa%2Fproduct%2FDark-olive-green%2F2-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Ffabric-sofa%2Fadrick-3-seater-sofa%2Fproduct%2FDark-olive-green%2F3-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2FA-website-fabric-shoot%2FDark-olive-green%2F3-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Ffabric-sofa%2Fadrick-3-seater-sofa%2Fdimension-up%2Fl2-810x702.jpg;https://images.woodenstreet.de/image/cache/data%2Ffabric-sofa%2Fadrick-3-seater-sofa%2Fproduct%2FDark-olive-green%2F4-810x702.jpg', 'About Material & ColorsMade of premium-quality material, this 3 seater fabric sofa is sturdy in nature and offers long-lasting durability. The two fabric options available in this unit are Cotton and Velvet. Moreover, both these fabrics are available in varied colour and print options to match diverse decor aesthetics.Manufacturing Details & Stringent Quality ChecksOur artisans ensure every minute details to achieve the extreme accuracy and level of perfection. The final product, before reaching your doorstep, the product passes through stringent quality checks. Product FeaturesDiscover the peak of elegance with our Lorenz 3 Seater Sofa. This stunning piece of furniture is a testament to exquisite design and detailed craftsmanship. The soft and breathable upholstery offers a calming aura, creating a harmonious blend that soothes the senses. The tufted backrest and gracefully curved armrests add a touch of classic charm, making this sofa a timeless beauty.Detail is where our Lorenz 3 seater sofa shines. Every stitch and line showcases the skill and dedication of the artisans who brought this masterpiece to life. The thoughtfully crafted silhouette complements any interior, making it an easy fit for both modern and traditional settings. Sink into the generously padded seats and backrests for ultimate relaxation with our Lorenz 3 Seater Sofa. Crafted with a sturdy wooden frame, this sofa promises both durability and luxury, adding a touch of sophistication to your home for years to come.', 45321, 100, 'SPORTS SHOES', 1),
(11, 'MEN\'S ADIDAS RUNNING KALUS SHOES', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSrEqFHfSbs6rUzcYnN_PcnS_D2JLXusKMVFk4Y8N_tn3hJgNIf', NULL, 'A well cushioned shoe with a fresher look that will appeal to young runners. Features Mesh upper for maximum ventilation, lightstrike IMEVA midsole with visible adiprene providing protection from harmful impact forces and durable Rubber outsole for long-lasting wear', 39.99, 100, 'SPORTS SHOES', 1),
(12, 'Xbox One X Star Wars Jedi', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ8ufSADR9EyusxEfgMLErqISEcKVzQyjoD81zWcdpBvuEGBnYP', NULL, 'Own the Xbox One X Star Wars Jedi: Fallen Order™ Bundle and step into the role of a Jedi Padawan who narrowly escaped the purge of Order 66. This bundle includes a full-game download of Star Wars Jedi: Fallen Order™ Deluxe Edition, a 1-month trial of Xbox Game Pass for console and Xbox Live Gold, and 1-month of EA Access.***', 250, 100, 'Gaming console', 2),
(13, 'PlayStation 4', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSr-iFW5W8n3_jxNKiclAP_k71Fi9PGcojsMUC-vb8zbwJthbBd', NULL, 'With PS4, gaming becomes a lot more power packed. Ultra-fast processors, high-performance system, real-time game sharing, remote play and lots more makes it the ultimate companion device.', 240.99, 68, 'Gaming console', 2),
(14, 'PEGASUS 33 Running Shoes For Men', 'https://i.pinimg.com/originals/43/40/8e/43408ee5a8d234752ecf80bbc3832e65.jpg', NULL, 'The Nike Zoom Pegasus Turbo 2 is updated with a feather-light upper, while innovative foam brings revolutionary responsiveness to your long-distance training', 59.99, 100, 'SPORTS SHOES', 1),
(15, 'MEN\'S ADIDAS RUNNING KALUS SHOES', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSrEqFHfSbs6rUzcYnN_PcnS_D2JLXusKMVFk4Y8N_tn3hJgNIf', NULL, 'A well cushioned shoe with a fresher look that will appeal to young runners. Features Mesh upper for maximum ventilation, lightstrike IMEVA midsole with visible adiprene providing protection from harmful impact forces and durable Rubber outsole for long-lasting wear', 39.99, 100, 'SPORTS SHOES', 1),
(16, 'Xbox One X Star Wars Jedi', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ8ufSADR9EyusxEfgMLErqISEcKVzQyjoD81zWcdpBvuEGBnYP', NULL, 'Own the Xbox One X Star Wars Jedi: Fallen Order™ Bundle and step into the role of a Jedi Padawan who narrowly escaped the purge of Order 66. This bundle includes a full-game download of Star Wars Jedi: Fallen Order™ Deluxe Edition, a 1-month trial of Xbox Game Pass for console and Xbox Live Gold, and 1-month of EA Access.***', 250, 100, 'Gaming console', 2),
(17, 'PlayStation 4', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSr-iFW5W8n3_jxNKiclAP_k71Fi9PGcojsMUC-vb8zbwJthbBd', NULL, 'With PS4, gaming becomes a lot more power packed. Ultra-fast processors, high-performance system, real-time game sharing, remote play and lots more makes it the ultimate companion device.', 240.99, 100, 'Gaming console', 2),
(18, 'PEGASUS 33 Running Shoes For Men', 'https://i.pinimg.com/originals/43/40/8e/43408ee5a8d234752ecf80bbc3832e65.jpg', NULL, 'The Nike Zoom Pegasus Turbo 2 is updated with a feather-light upper, while innovative foam brings revolutionary responsiveness to your long-distance training', 59.99, 80, 'SPORTS SHOES', 1),
(19, 'MEN\'S ADIDAS RUNNING KALUS SHOES', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSrEqFHfSbs6rUzcYnN_PcnS_D2JLXusKMVFk4Y8N_tn3hJgNIf', NULL, 'A well cushioned shoe with a fresher look that will appeal to young runners. Features Mesh upper for maximum ventilation, lightstrike IMEVA midsole with visible adiprene providing protection from harmful impact forces and durable Rubber outsole for long-lasting wear', 39.99, 100, 'SPORTS SHOES', 1),
(20, 'Xbox One X Star Wars Jedi', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ8ufSADR9EyusxEfgMLErqISEcKVzQyjoD81zWcdpBvuEGBnYP', NULL, 'Own the Xbox One X Star Wars Jedi: Fallen Order™ Bundle and step into the role of a Jedi Padawan who narrowly escaped the purge of Order 66. This bundle includes a full-game download of Star Wars Jedi: Fallen Order™ Deluxe Edition, a 1-month trial of Xbox Game Pass for console and Xbox Live Gold, and 1-month of EA Access.***', 250, 100, 'Gaming console', 2),
(21, 'PlayStation 4', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSr-iFW5W8n3_jxNKiclAP_k71Fi9PGcojsMUC-vb8zbwJthbBd', NULL, 'With PS4, gaming becomes a lot more power packed. Ultra-fast processors, high-performance system, real-time game sharing, remote play and lots more makes it the ultimate companion device.', 240.99, 100, 'Gaming console', 2),
(22, 'PEGASUS 33 Running Shoes For Men', 'https://i.pinimg.com/originals/43/40/8e/43408ee5a8d234752ecf80bbc3832e65.jpg', NULL, 'The Nike Zoom Pegasus Turbo 2 is updated with a feather-light upper, while innovative foam brings revolutionary responsiveness to your long-distance training', 59.99, 100, 'SPORTS SHOES', 1),
(23, 'MEN\'S ADIDAS RUNNING KALUS SHOES', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSrEqFHfSbs6rUzcYnN_PcnS_D2JLXusKMVFk4Y8N_tn3hJgNIf', NULL, 'A well cushioned shoe with a fresher look that will appeal to young runners. Features Mesh upper for maximum ventilation, lightstrike IMEVA midsole with visible adiprene providing protection from harmful impact forces and durable Rubber outsole for long-lasting wear', 39.99, 100, 'SPORTS SHOES', 1),
(24, 'Xbox One X Star Wars Jedi', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ8ufSADR9EyusxEfgMLErqISEcKVzQyjoD81zWcdpBvuEGBnYP', NULL, 'Own the Xbox One X Star Wars Jedi: Fallen Order™ Bundle and step into the role of a Jedi Padawan who narrowly escaped the purge of Order 66. This bundle includes a full-game download of Star Wars Jedi: Fallen Order™ Deluxe Edition, a 1-month trial of Xbox Game Pass for console and Xbox Live Gold, and 1-month of EA Access.***', 250, 100, 'Gaming console', 2),
(25, 'PlayStation 4', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSr-iFW5W8n3_jxNKiclAP_k71Fi9PGcojsMUC-vb8zbwJthbBd', NULL, 'With PS4, gaming becomes a lot more power packed. Ultra-fast processors, high-performance system, real-time game sharing, remote play and lots more makes it the ultimate companion device.', 240.99, 100, 'Gaming console', 2),
(26, 'PEGASUS 33 Running Shoes For Men', 'https://i.pinimg.com/originals/43/40/8e/43408ee5a8d234752ecf80bbc3832e65.jpg', NULL, 'The Nike Zoom Pegasus Turbo 2 is updated with a feather-light upper, while innovative foam brings revolutionary responsiveness to your long-distance training', 59.99, 100, 'SPORTS SHOES', 1),
(27, 'MEN\'S ADIDAS RUNNING KALUS SHOES', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSrEqFHfSbs6rUzcYnN_PcnS_D2JLXusKMVFk4Y8N_tn3hJgNIf', NULL, 'A well cushioned shoe with a fresher look that will appeal to young runners. Features Mesh upper for maximum ventilation, lightstrike IMEVA midsole with visible adiprene providing protection from harmful impact forces and durable Rubber outsole for long-lasting wear', 39.99, 100, 'SPORTS SHOES', 1),
(28, 'Xbox One X Star Wars Jedi', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ8ufSADR9EyusxEfgMLErqISEcKVzQyjoD81zWcdpBvuEGBnYP', NULL, 'Own the Xbox One X Star Wars Jedi: Fallen Order™ Bundle and step into the role of a Jedi Padawan who narrowly escaped the purge of Order 66. This bundle includes a full-game download of Star Wars Jedi: Fallen Order™ Deluxe Edition, a 1-month trial of Xbox Game Pass for console and Xbox Live Gold, and 1-month of EA Access.***', 250, 100, 'Gaming console', 2),
(29, 'PlayStation 4', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSr-iFW5W8n3_jxNKiclAP_k71Fi9PGcojsMUC-vb8zbwJthbBd', NULL, 'With PS4, gaming becomes a lot more power packed. Ultra-fast processors, high-performance system, real-time game sharing, remote play and lots more makes it the ultimate companion device.', 240.99, 100, 'Gaming console', 2),
(30, 'PEGASUS 33 Running Shoes For Men', 'https://i.pinimg.com/originals/43/40/8e/43408ee5a8d234752ecf80bbc3832e65.jpg', NULL, 'The Nike Zoom Pegasus Turbo 2 is updated with a feather-light upper, while innovative foam brings revolutionary responsiveness to your long-distance training', 59.99, 100, 'SPORTS SHOES', 1),
(31, 'MEN\'S ADIDAS RUNNING KALUS SHOES', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSrEqFHfSbs6rUzcYnN_PcnS_D2JLXusKMVFk4Y8N_tn3hJgNIf', NULL, 'A well cushioned shoe with a fresher look that will appeal to young runners. Features Mesh upper for maximum ventilation, lightstrike IMEVA midsole with visible adiprene providing protection from harmful impact forces and durable Rubber outsole for long-lasting wear', 39.99, 100, 'SPORTS SHOES', 1),
(32, 'Xbox One X Star Wars Jedi', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ8ufSADR9EyusxEfgMLErqISEcKVzQyjoD81zWcdpBvuEGBnYP', NULL, 'Own the Xbox One X Star Wars Jedi: Fallen Order™ Bundle and step into the role of a Jedi Padawan who narrowly escaped the purge of Order 66. This bundle includes a full-game download of Star Wars Jedi: Fallen Order™ Deluxe Edition, a 1-month trial of Xbox Game Pass for console and Xbox Live Gold, and 1-month of EA Access.***', 250, 88, 'Gaming console', 2),
(33, 'PEGASUS 33 Running Shoes For Men', 'https://i.pinimg.com/originals/43/40/8e/43408ee5a8d234752ecf80bbc3832e65.jpg', NULL, 'The Nike Zoom Pegasus Turbo 2 is updated with a feather-light upper, while innovative foam brings revolutionary responsiveness to your long-distance training', 59.99, 100, 'SPORTS SHOES', 1),
(34, 'MEN\'S ADIDAS RUNNING KALUS SHOES', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSrEqFHfSbs6rUzcYnN_PcnS_D2JLXusKMVFk4Y8N_tn3hJgNIf', NULL, 'A well cushioned shoe with a fresher look that will appeal to young runners. Features Mesh upper for maximum ventilation, lightstrike IMEVA midsole with visible adiprene providing protection from harmful impact forces and durable Rubber outsole for long-lasting wear', 39.99, 100, 'SPORTS SHOES', 1),
(35, 'Xbox One X Star Wars Jedi', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ8ufSADR9EyusxEfgMLErqISEcKVzQyjoD81zWcdpBvuEGBnYP', NULL, 'Own the Xbox One X Star Wars Jedi: Fallen Order™ Bundle and step into the role of a Jedi Padawan who narrowly escaped the purge of Order 66. This bundle includes a full-game download of Star Wars Jedi: Fallen Order™ Deluxe Edition, a 1-month trial of Xbox Game Pass for console and Xbox Live Gold, and 1-month of EA Access.***', 250, 100, 'Gaming console', 2),
(36, 'PlayStation 4', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSr-iFW5W8n3_jxNKiclAP_k71Fi9PGcojsMUC-vb8zbwJthbBd', NULL, 'With PS4, gaming becomes a lot more power packed. Ultra-fast processors, high-performance system, real-time game sharing, remote play and lots more makes it the ultimate companion device.', 240.99, 100, 'Gaming console', 2),
(37, 'PEGASUS 33 Running Shoes For Men', 'https://i.pinimg.com/originals/43/40/8e/43408ee5a8d234752ecf80bbc3832e65.jpg', NULL, 'The Nike Zoom Pegasus Turbo 2 is updated with a feather-light upper, while innovative foam brings revolutionary responsiveness to your long-distance training', 59.99, 100, 'SPORTS SHOES', 1),
(38, 'MEN\'S ADIDAS RUNNING KALUS SHOES', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSrEqFHfSbs6rUzcYnN_PcnS_D2JLXusKMVFk4Y8N_tn3hJgNIf', NULL, 'A well cushioned shoe with a fresher look that will appeal to young runners. Features Mesh upper for maximum ventilation, lightstrike IMEVA midsole with visible adiprene providing protection from harmful impact forces and durable Rubber outsole for long-lasting wear', 39.99, 100, 'SPORTS SHOES', 1),
(39, 'Xbox One X Star Wars Jedi', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ8ufSADR9EyusxEfgMLErqISEcKVzQyjoD81zWcdpBvuEGBnYP', NULL, 'Own the Xbox One X Star Wars Jedi: Fallen Order™ Bundle and step into the role of a Jedi Padawan who narrowly escaped the purge of Order 66. This bundle includes a full-game download of Star Wars Jedi: Fallen Order™ Deluxe Edition, a 1-month trial of Xbox Game Pass for console and Xbox Live Gold, and 1-month of EA Access.***', 250, 100, 'Gaming console', 2),
(40, 'PEGASUS 33 Running Shoes For Men', 'https://i.pinimg.com/originals/43/40/8e/43408ee5a8d234752ecf80bbc3832e65.jpg', NULL, 'The Nike Zoom Pegasus Turbo 2 is updated with a feather-light upper, while innovative foam brings revolutionary responsiveness to your long-distance training', 59.99, 100, 'SPORTS SHOES', 1),
(41, 'MEN\'S ADIDAS RUNNING KALUS SHOES', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSrEqFHfSbs6rUzcYnN_PcnS_D2JLXusKMVFk4Y8N_tn3hJgNIf', NULL, 'A well cushioned shoe with a fresher look that will appeal to young runners. Features Mesh upper for maximum ventilation, lightstrike IMEVA midsole with visible adiprene providing protection from harmful impact forces and durable Rubber outsole for long-lasting wear', 39.99, 100, 'SPORTS SHOES', 1),
(42, 'Xbox One X Star Wars Jedi', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ8ufSADR9EyusxEfgMLErqISEcKVzQyjoD81zWcdpBvuEGBnYP', NULL, 'Own the Xbox One X Star Wars Jedi: Fallen Order™ Bundle and step into the role of a Jedi Padawan who narrowly escaped the purge of Order 66. This bundle includes a full-game download of Star Wars Jedi: Fallen Order™ Deluxe Edition, a 1-month trial of Xbox Game Pass for console and Xbox Live Gold, and 1-month of EA Access.***', 250, 100, 'Gaming console', 2),
(43, 'PlayStation 4', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSr-iFW5W8n3_jxNKiclAP_k71Fi9PGcojsMUC-vb8zbwJthbBd', NULL, 'With PS4, gaming becomes a lot more power packed. Ultra-fast processors, high-performance system, real-time game sharing, remote play and lots more makes it the ultimate companion device.', 240.99, 100, 'Gaming console', 2),
(44, 'PEGASUS 33 Running Shoes For Men', 'https://i.pinimg.com/originals/43/40/8e/43408ee5a8d234752ecf80bbc3832e65.jpg', NULL, 'The Nike Zoom Pegasus Turbo 2 is updated with a feather-light upper, while innovative foam brings revolutionary responsiveness to your long-distance training', 59.99, 100, 'SPORTS SHOES', 1),
(45, 'MEN\'S ADIDAS RUNNING KALUS SHOES', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSrEqFHfSbs6rUzcYnN_PcnS_D2JLXusKMVFk4Y8N_tn3hJgNIf', NULL, 'A well cushioned shoe with a fresher look that will appeal to young runners. Features Mesh upper for maximum ventilation, lightstrike IMEVA midsole with visible adiprene providing protection from harmful impact forces and durable Rubber outsole for long-lasting wear', 39.99, 100, 'SPORTS SHOES', 1),
(46, 'Xbox One X Star Wars Jedi', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ8ufSADR9EyusxEfgMLErqISEcKVzQyjoD81zWcdpBvuEGBnYP', NULL, 'Own the Xbox One X Star Wars Jedi: Fallen Order™ Bundle and step into the role of a Jedi Padawan who narrowly escaped the purge of Order 66. This bundle includes a full-game download of Star Wars Jedi: Fallen Order™ Deluxe Edition, a 1-month trial of Xbox Game Pass for console and Xbox Live Gold, and 1-month of EA Access.***', 250, 100, 'Gaming console', 2),
(47, 'PEGASUS 33 Running Shoes For Men', 'https://i.pinimg.com/originals/43/40/8e/43408ee5a8d234752ecf80bbc3832e65.jpg', NULL, 'The Nike Zoom Pegasus Turbo 2 is updated with a feather-light upper, while innovative foam brings revolutionary responsiveness to your long-distance training', 59.99, 100, 'SPORTS SHOES', 1),
(48, 'MEN\'S ADIDAS RUNNING KALUS SHOES', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSrEqFHfSbs6rUzcYnN_PcnS_D2JLXusKMVFk4Y8N_tn3hJgNIf', NULL, 'A well cushioned shoe with a fresher look that will appeal to young runners. Features Mesh upper for maximum ventilation, lightstrike IMEVA midsole with visible adiprene providing protection from harmful impact forces and durable Rubber outsole for long-lasting wear', 39.99, 100, 'SPORTS SHOES', 1),
(49, 'Xbox One X Star Wars Jedi', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ8ufSADR9EyusxEfgMLErqISEcKVzQyjoD81zWcdpBvuEGBnYP', NULL, 'Own the Xbox One X Star Wars Jedi: Fallen Order™ Bundle and step into the role of a Jedi Padawan who narrowly escaped the purge of Order 66. This bundle includes a full-game download of Star Wars Jedi: Fallen Order™ Deluxe Edition, a 1-month trial of Xbox Game Pass for console and Xbox Live Gold, and 1-month of EA Access.***', 250, 100, 'Gaming console', 2),
(50, 'PlayStation 4', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSr-iFW5W8n3_jxNKiclAP_k71Fi9PGcojsMUC-vb8zbwJthbBd', NULL, 'With PS4, gaming becomes a lot more power packed. Ultra-fast processors, high-performance system, real-time game sharing, remote play and lots more makes it the ultimate companion device.', 240.99, 100, 'Gaming console', 2),
(51, 'PEGASUS 33 Running Shoes For Men', 'https://i.pinimg.com/originals/43/40/8e/43408ee5a8d234752ecf80bbc3832e65.jpg', NULL, 'The Nike Zoom Pegasus Turbo 2 is updated with a feather-light upper, while innovative foam brings revolutionary responsiveness to your long-distance training', 59.99, 100, 'SPORTS SHOES', 1),
(52, 'MEN\'S ADIDAS RUNNING KALUS SHOES', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSrEqFHfSbs6rUzcYnN_PcnS_D2JLXusKMVFk4Y8N_tn3hJgNIf', NULL, 'A well cushioned shoe with a fresher look that will appeal to young runners. Features Mesh upper for maximum ventilation, lightstrike IMEVA midsole with visible adiprene providing protection from harmful impact forces and durable Rubber outsole for long-lasting wear', 39.99, 100, 'SPORTS SHOES', 1),
(53, 'Xbox One X Star Wars Jedi', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ8ufSADR9EyusxEfgMLErqISEcKVzQyjoD81zWcdpBvuEGBnYP', NULL, 'Own the Xbox One X Star Wars Jedi: Fallen Order™ Bundle and step into the role of a Jedi Padawan who narrowly escaped the purge of Order 66. This bundle includes a full-game download of Star Wars Jedi: Fallen Order™ Deluxe Edition, a 1-month trial of Xbox Game Pass for console and Xbox Live Gold, and 1-month of EA Access.***', 250, 100, 'Gaming console', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `fname` varchar(255) DEFAULT 'not set',
  `lname` varchar(255) DEFAULT 'not set',
  `age` int(10) DEFAULT 18,
  `role` int(10) DEFAULT 555,
  `photoUrl` text DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'local'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `fname`, `lname`, `age`, `role`, `photoUrl`, `type`) VALUES
(11, 'mike', '$2b$10$vIS0W3LKhbx2tFh1GMYWhul7GWtIg4jnKU2C/NGux1pUG3QKMdNzO', 'mike-doe@excellent.com', 'Mike', 'Leming', 40, 555, 'https://i.pinimg.com/originals/dc/55/a0/dc55a0fec14d93d9cf6fa32c32f7c7f2.jpg', 'local'),
(22, 'vijay', '123456', 'ervijaykokate@gmail.com', 'not set', 'not set', 18, 555, NULL, 'local');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_addresses_users1_idx` (`user_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_orders_users1_idx` (`user_id`);

--
-- Indexes for table `orders_details`
--
ALTER TABLE `orders_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_orders_has_products_products1_idx` (`product_id`),
  ADD KEY `fk_orders_has_products_orders1_idx` (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_ibfk_1` (`cat_id`);
ALTER TABLE `products` ADD FULLTEXT KEY `description` (`description`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=160;

--
-- AUTO_INCREMENT for table `orders_details`
--
ALTER TABLE `orders_details`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=198;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addresses`
--
ALTER TABLE `addresses`
  ADD CONSTRAINT `fk_addresses_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders_details`
--
ALTER TABLE `orders_details`
  ADD CONSTRAINT `fk_orders_has_products_orders1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_orders_has_products_products1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
